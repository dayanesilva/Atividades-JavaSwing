/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author dayan
 */
public class Exercicio3 implements ActionListener{
    JTextField tf1, tf2;
    JButton b;
    JLabel l;
    
    Exercicio3(){
        JFrame f = new JFrame("Nome e Sobrenome");
        tf1 = new JTextField();
        tf1.setBounds(50,50,300,20);
        tf2 = new JTextField();
        tf2.setBounds(50,100,300,20);
        l = new JLabel();
        l.setBounds(50,150,300,20);
        b = new JButton("Nome Completo");
        b.setBounds(50,200,300,50);
        b.addActionListener(this);
        f.add(tf1);
        f.add(tf2);
        f.add(l);
        f.add(b);
        f.setSize(450,350);
        f.setLayout(null);
        f.setVisible(true);
    }
    public void actionPerformed(ActionEvent e){
        String nome = tf1.getText();
        String sobrenome = tf2.getText();
        
        if(e.getSource() == b){
            l.setText(nome + " " +sobrenome);
        }
    }
    public static void main(String[] args){
        new Exercicio3();
    }
}
