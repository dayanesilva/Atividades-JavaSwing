/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author dayan
 */
public class Exercicio2 implements ActionListener{
    JTextField tf1, tf2, tf3, tf4;
    JButton b;
    JLabel l1, l2;
    
    Exercicio2(){
        JFrame f = new JFrame("Média");
        tf1 = new JTextField();
        tf1.setBounds(50,50,150,20);
        tf2 = new JTextField();
        tf2.setBounds(50,100,150,20);
        tf3 = new JTextField();
        tf3.setBounds(50,150,150,20);
        tf4 = new JTextField();
        tf4.setBounds(50,200,150,20);
        l1 = new JLabel();
        l1.setBounds(50,250,150,20);
        l2 = new JLabel();
        l2.setBounds(50,300,150,20);
        b = new JButton("Resultado");
        b.setBounds(50,350,150,50);
        b.addActionListener(this);
        f.add(tf1);
        f.add(tf2);
        f.add(tf3);
        f.add(tf4);
        f.add(l1);
        f.add(l2);
        f.add(b);
        f.setSize(300,550);
        f.setLayout(null);
        f.setVisible(true);
    }
    public void actionPerformed(ActionEvent e){
        String s1 = tf1.getText();
        String s2 = tf2.getText();
        String s3 = tf3.getText();
        String s4 = tf4.getText();
        
        float n1 = Float.parseFloat(s1);
        float n2 = Float.parseFloat(s2);
        float n3 = Float.parseFloat(s3);
        float n4 = Float.parseFloat(s4);
        
        float media = (n1+n2+n3+n4)/4;
        
        String ap = "Aprovado";
        String re = "Reprovado";
        
        if(e.getSource() == b){
            if(media >= 6){
                l2.setText(ap);
            }
            else{
                l2.setText(re);
            }
        }
    String result = String.valueOf(media);
    l1.setText("Média: "+result);
    }
    public static void main(String[] args){
        new Exercicio2();
    }
}
