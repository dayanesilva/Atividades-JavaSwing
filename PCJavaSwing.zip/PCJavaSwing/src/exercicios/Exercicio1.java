/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author dayan
 */
public class Exercicio1 implements ActionListener{
    JTextField tf1, tf2;
    JButton b;
    JLabel l1, l2;
    
    Exercicio1(){
        JFrame f = new JFrame("Divisão");
        tf1 = new JTextField();
        tf1.setBounds(50,50,150,20);
        tf2 = new JTextField();
        tf2.setBounds(50,100,150,20);
        l1 = new JLabel();
        l1.setBounds(50,150,150,20);
        l2 = new JLabel();
        l2.setBounds(50,200,150,20);
        b = new JButton("Dividir");
        b.setBounds(50,250,150,50);
        b.addActionListener(this);
        f.add(tf1);
        f.add(tf2);
        f.add(l1);
        f.add(l2);
        f.add(b);
        f.setSize(300,400);
        f.setLayout(null);
        f.setVisible(true);
    }
    public void actionPerformed(ActionEvent e){
        String s1 = tf1.getText();
        String s2 = tf2.getText();
        
        float n1 = Float.parseFloat(s1);
        float n2 = Float.parseFloat(s2);
        
        float divisao=0;
        String erro = "Impossível dividir por 0";
        
        if(e.getSource() == b){
            if(n2 == 0){
                divisao = n1 / 1;
                l2.setText(erro);
            }
            else{
                divisao = n1 / n2;
            }
        }
    String result = String.valueOf(divisao);
    l1.setText(result);
    }
    public static void main(String[] args){
        new Exercicio1();
    }
}

